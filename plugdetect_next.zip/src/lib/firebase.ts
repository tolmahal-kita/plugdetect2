import { initializeApp, getApp, getApps } from "firebase/app";

export const firebaseConfig = {
  projectId: "studio-2732920271-b0051",
  appId: "1:479199464389:web:2d1d71e32bc52755fc99ac",
  apiKey: "AIzaSyBDD17SkQhXOzM82cfnHqMuK6UZ38xZnLs",
  authDomain: "studio-2732920271-b0051.firebaseapp.com",
  messagingSenderId: "479199464389",
  databaseURL: "https://studio-2732920271-b0051.firebaseio.com",
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export { app };