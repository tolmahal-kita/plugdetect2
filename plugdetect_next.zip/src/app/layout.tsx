import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'PlugDetect',
  description: 'Detect and manage your plugged-in devices.',
};

export default function RootLayout({ children }: { children: React.ReactNode; }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}